from PIL import Image 
# create an image via import  
image1 = Image.open('insect1.PNG')
image2 = Image.open('insect2.PNG')
image3 = Image.open('insect3.PNG')
#-----------------------------------Image1
#analyze the image  
print(image1.size) 
print(image1.filename) 
print(image1.format) 
# flip the image 
image1 = image1.transpose(Image.Transpose.ROTATE_90) 
# show the image  
image1.show() 
#exercise  
img1_rotated = image1.rotate(30) 
img1_rotated.save('img1_rotated.png', 'png') 

#-----------------------------------Image2
#analyze the image  
print(image2.size) 
print(image2.filename) 
print(image2.format) 
# flip the image 
image2 = image2.transpose(Image.Transpose.ROTATE_90) 
# show the image  
image2.show() 
#exercise  
img2_rotated = image2.rotate(30) 
img2_rotated.save('img2_rotated.png', 'png') 


#-----------------------------------Image3
#analyze the image  
print(image3.size) 
print(image3.filename) 
print(image3.format) 
# flip the image 
image3 = image3.transpose(Image.Transpose.ROTATE_90) 
# show the image  
image3.show() 
#exercise  
img3_rotated = image3.rotate(30) 
img3_rotated.save('img3_rotated.png', 'png') 