from PIL import Image  
image1 = Image.open('insect1.PNG')
image2 = Image.open('insect2.PNG')
image3 = Image.open('insect3.PNG')
# get one pixel  ------------------------------------------------------------
print(image1.getpixel((0,0)))
print(image2.getpixel((0,0)))
print(image3.getpixel((0,0))) 
# grayscale images  ---------------------------------------------------------
red_grayscale_image1 = image1.getchannel('R') 
blue_grayscale_image1 = image1.getchannel('B') 
red_grayscale_image1.show()                       
blue_grayscale_image1.show() 

red_grayscale_image2 = image2.getchannel('R') 
blue_grayscale_image2 = image2.getchannel('B') 
# red_grayscale_image2.show() 
# blue_grayscale_image2.show()                  commented out show() functions as too many images are generated

red_grayscale_image3 = image2.getchannel('R') 
blue_grayscale_image3 = image2.getchannel('B') 
# red_grayscale_image3.show() 
# blue_grayscale_image3.show()


# change the pixel color  ---------------------------------------------------
image1.putpixel((0,0), (255,0,255)) 
image2.putpixel((0,0), (255,0,255)) 
image3.putpixel((0,0), (255,0,255)) 

image1.show() 
# image2.show()
# image3.show() 


# explore --------------------------------------------------------------------
print(image1.getpixel((0,0))) 
for x in range(image1.size[0]): 
    for y in range(image1.size[1]): 
        if image1.getpixel((x,y))[0] == 0: 
            image1.putpixel((x,y), (200,20,20)) 
image1.show()

print(image2.getpixel((0,0))) 
for x in range(image2.size[0]): 
    for y in range(image2.size[1]): 
        if image2.getpixel((x,y))[0] == 0: 
            image2.putpixel((x,y), (200,20,20)) 
image2.show()

print(image3.getpixel((0,0))) 
for x in range(image3.size[0]): 
    for y in range(image3.size[1]): 
        if image3.getpixel((x,y))[0] == 0: 
            image3.putpixel((x,y), (200,20,20)) 
image3.show()