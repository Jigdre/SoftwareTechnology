from PIL import Image, ImageEnhance 


# import an image  
image1 = Image.open('insect1.PNG')
image2 = Image.open('insect2.PNG')
image3 = Image.open('insect3.PNG')




# create an enhancer 
vibrance_enhancer = ImageEnhance.Color(image1) 
contrast_enhancer = ImageEnhance.Contrast(image2) 
brightness_enhancer = ImageEnhance.Brightness(image3) 
sharpness_enhancer = ImageEnhance.Sharpness(image1) 





# apply the enhancer  
sharpness_enhanced_image1 = sharpness_enhancer.enhance(5) 
contrast_enhanced_image2 = contrast_enhancer.enhance(5)
brightness_enhanced_image3=brightness_enhancer.enhance(5)




# show  

sharpness_enhanced_image1.show()
contrast_enhanced_image2.show()
brightness_enhanced_image3.show()