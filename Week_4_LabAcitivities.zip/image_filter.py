from PIL import Image, ImageFilter 


# create an image  
image = Image.open('cat.jpg') 
image1 = Image.open('insect1.PNG')
image2 = Image.open('insect2.PNG')
image3 = Image.open('insect3.PNG')



# apply a basic filter 
image_blur1 = image1.filter(ImageFilter.BLUR) 
image_contour = image.filter(ImageFilter.CONTOUR) 
image_emboss = image.filter(ImageFilter.EMBOSS) 
image_edge2 = image2.filter(ImageFilter.FIND_EDGES) 



# apply advanced filters 
image_boxblur = image.filter(ImageFilter.BoxBlur(radius = 20)) 
image_gaussianblur = image.filter(ImageFilter.GaussianBlur(radius = 20)) 
image_unsharp3 = image3.filter(ImageFilter.UnsharpMask(radius = 20)) 




image_blur1.show()
image_edge2.show()
image_unsharp3.show()
