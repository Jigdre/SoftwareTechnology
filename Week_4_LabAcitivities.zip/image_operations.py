from PIL import Image, ImageOps 
# create an image 
image = Image.open('dog.jpg') 
image1 = Image.open('insect1.PNG')
image2 = Image.open('insect2.PNG')
image3 = Image.open('insect3.PNG')

# position changes  
image_mirror1 = ImageOps.mirror(image1) 
image_scale2 = ImageOps.scale(image2, 0.5) 


# color changes  
image_inverted1 = ImageOps.invert(image_mirror1) 


# add and remove  
image_border = ImageOps.expand( 
    image = image_inverted1,  
    border = 50, 
    fill = (255,255,255)) 
image_padded = ImageOps.pad(image, (4000,6000)) 
image_crop3 = ImageOps.crop(image = image3, border = 200) 


image_inverted1.show()
image_scale2.show()
image_crop3.show()
