from PIL import Image  
# import an image  
image1 = Image.open('insect1.PNG')
image2 = Image.open('insect2.PNG')
image3 = Image.open('insect3.PNG')
# flip  
image1_transpose = image1.transpose(Image.Transpose.ROTATE_90)
image2_transpose = image2.transpose(Image.Transpose.ROTATE_90)
image3_transpose = image3.transpose(Image.Transpose.ROTATE_90)

# rotation  
image1_rotate = image1.rotate(45, expand = False, center = (0,0)) 
image2_rotate = image2.rotate(45, expand = False, center = (0,0)) 
image3_rotate = image3.rotate(45, expand = False, center = (0,0)) 
# crop 
image1_crop = image1.crop((800,600,1600,1600)) 
image2_crop = image2.crop((800,600,1600,1600)) 
image3_crop = image3.crop((800,600,1600,1600)) 

# resize  
image1_resize = image1.resize((1000,600)) 
image2_resize = image2.resize((1000,600)) 
image3_resize = image3.resize((1000,600)) 


# applying multiple transformations to an image in a single line of 
#code 
combined_image1 = image1.transpose(Image.Transpose.ROTATE_90).resize((2000,1500)).rotate(10) 
combined_image1.show() 

combined_image2 = image2.transpose(Image.Transpose.ROTATE_90).resize((2000,1500)).rotate(10) 
combined_image2.show()

combined_image3 = image3.transpose(Image.Transpose.ROTATE_90).resize((2000,1500)).rotate(10) 
combined_image3.show() 